package atmtask;


import java.util.Scanner;

public class ATM {
    private Bank bank;
    private Scanner sc = new Scanner(System.in);

    public ATM(Bank bank) {
        this.bank = bank;
    }

    public void start() {
        Account account = null;

        for (int i = 1; i <= 3; i++) {
            System.out.print("Enter User ID: ");
            String id = sc.nextLine();

            System.out.print("Enter PIN: ");
            String pin = sc.nextLine();

            Account found = bank.getAccount(id);

            if (found != null && found.checkPin(pin)) {
                account = found;
                break;
            }

            System.out.println("Invalid User ID or PIN.");
            System.out.println("Attempts left: " + (3 - i));
        }

        if (account == null) {
            System.out.println("Access denied. Too many incorrect attempts.");
            return;
        }

        System.out.println("Login successful!");
        boolean running = true;

        while (running) {
            System.out.println("\n--- ATM MENU ---");
            System.out.println("1. Transaction History");
            System.out.println("2. Withdraw");
            System.out.println("3. Deposit");
            System.out.println("4. Transfer");
            System.out.println("5. Quit");
            System.out.print("Choose option: ");

            String choice = sc.nextLine();

            switch (choice) {
                case "1":
                    account.showHistory();
                    break;

                case "2":
                    System.out.print("Enter amount: ");
                    double withdrawAmount = readAmount();

                    if (account.withdraw(withdrawAmount)) {
                        System.out.println("Withdrawal successful.");
                    } else {
                        System.out.println("Invalid amount or Insufficient Funds.");
                    }
                    break;

                case "3":
                    System.out.print("Enter amount: ");
                    double depositAmount = readAmount();

                    if (depositAmount > 0) {
                        account.deposit(depositAmount);
                        System.out.println("Deposit successful.");
                    } else {
                        System.out.println("Amount must be greater than zero.");
                    }
                    break;

                case "4":
                    System.out.print("Recipient account ID: ");
                    String recipientId = sc.nextLine();

                    Account recipient = bank.getAccount(recipientId);

                    System.out.print("Transfer amount: ");
                    double transferAmount = readAmount();

                    if (recipient == null) {
                        System.out.println("Recipient account not found.");
                    } else if (recipient == account) {
                        System.out.println("Cannot transfer to the same account.");
                    } else if (transferAmount <= 0) {
                        System.out.println("Amount must be greater than zero.");
                    } else if (account.withdraw(transferAmount)) {
                        recipient.deposit(transferAmount);
                        account.addTransferRecord(
                            "Sent to " + recipientId, transferAmount
                        );
                        recipient.addTransferRecord(
                            "Received from " + account.getUserId(),
                            transferAmount
                        );
                        System.out.println("Transfer successful.");
                    } else {
                        System.out.println("Insufficient Funds.");
                    }
                    break;

                case "5":
                    System.out.println("Thank you for using the ATM.");
                    running = false;
                    break;

                default:
                    System.out.println("Invalid option. Try again.");
            }

            if (running) {
                System.out.println("Current balance: " + account.getBalance());
            }
        }
    }

    private double readAmount() {
        try {
            return Double.parseDouble(sc.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}

