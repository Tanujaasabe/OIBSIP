package atmtask;


import java.util.HashMap;
import java.util.Map;

public class Bank {
    private Map<String, Account> accounts = new HashMap<>();

    public Bank() {
        accounts.put("1001", new Account("1001", "1234", 5000));
        accounts.put("1002", new Account("1002", "2222", 3000));
    }

    public Account getAccount(String userId) {
        return accounts.get(userId);
    }
}

