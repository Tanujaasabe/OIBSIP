package atmtask;


import java.time.LocalDateTime;

public class Transaction {
    private String type;
    private double amount;
    private String details;
    private LocalDateTime time;

    public Transaction(String type, double amount, String details) {
        this.type = type;
        this.amount = amount;
        this.details = details;
        this.time = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return time + " | " + type + " | Amount: " + amount
                + " | " + details;
    }
}

