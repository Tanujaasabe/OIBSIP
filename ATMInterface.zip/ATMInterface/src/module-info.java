/**
 * 
 */
/**
 * 
 */
module ATMInterface {
}