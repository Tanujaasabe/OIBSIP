package com.guessingGame;


import java.util.Random;
import java.util.Scanner;

public class NumberGuessingGame {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        int round = 1;
        String playAgain;

        do {
            int number = random.nextInt(100) + 1;
            int attempts = 0;
            int maxAttempts = 7;
            boolean guessed = false;

            System.out.println("\n--- Round " + round + " ---");
            System.out.println("Guess a number between 1 and 100.");
            System.out.println("You have 7 attempts.");

            while (attempts < maxAttempts) {
                System.out.print("Enter your guess: ");
                int guess = sc.nextInt();
                attempts++;

                if (guess < 1 || guess > 100) {
                    System.out.println("Enter a number from 1 to 100.");
                    attempts--;
                    continue;
                }

                if (guess > number) {
                    System.out.println("Too High!");
                } else if (guess < number) {
                    System.out.println("Too Low!");
                } else {
                    System.out.println("Correct!");
                    System.out.println(
                        "You guessed it in " + attempts + " attempts."
                    );
                    guessed = true;
                    break;
                }

                System.out.println(
                    "Attempts remaining: " + (maxAttempts - attempts)
                );
            }

            if (!guessed) {
                System.out.println("You Lost!");
                System.out.println("The number was: " + number);
            }

            System.out.print("Play again? (yes/no): ");
            playAgain = sc.next();

            round++;

        } while (playAgain.equalsIgnoreCase("yes"));

        System.out.println("Thanks for playing!");
        sc.close();
    }
}

